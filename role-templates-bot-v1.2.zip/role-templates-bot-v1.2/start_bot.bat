@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo Установка discord.py...
python -m pip install -U discord.py

echo Запуск бота...
python role_templates_bot.py
pause
