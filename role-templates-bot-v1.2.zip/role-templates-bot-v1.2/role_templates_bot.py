import json
import os

import discord
from discord import app_commands

VERSION = "1.2"
TEMPLATES_FILE = "templates.json"
TOKEN_FILE = "token.txt"


def load_token() -> str:
    """Токен берётся из переменной DISCORD_TOKEN или из файла token.txt."""
    token = os.getenv("DISCORD_TOKEN")
    if not token and os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            token = f.read().strip()
    if not token:
        raise SystemExit(
            "Токен не найден. Создай файл token.txt рядом со скриптом "
            "и вставь в него токен бота."
        )
    return token


# ---------- работа с файлом шаблонов ----------
def load_templates() -> dict:
    if not os.path.exists(TEMPLATES_FILE):
        return {}
    with open(TEMPLATES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_templates(data: dict) -> None:
    with open(TEMPLATES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ---------- права ролей в каналах (overwrites) ----------
def serialize_overwrites(channel) -> list:
    result = []
    for target, overwrite in channel.overwrites.items():
        if not isinstance(target, discord.Role):
            continue  # права отдельных участников не копируем
        allow, deny = overwrite.pair()
        result.append({
            "role": target.name,
            "everyone": target.is_default(),
            "allow": allow.value,
            "deny": deny.value,
        })
    return result


def build_overwrites(guild, role_map: dict, saved: list) -> dict:
    result = {}
    for item in saved:
        role = guild.default_role if item["everyone"] else role_map.get(item["role"])
        if role is None:
            continue
        result[role] = discord.PermissionOverwrite.from_pair(
            discord.Permissions(item["allow"]),
            discord.Permissions(item["deny"]),
        )
    return result


# ---------- сбор данных с сервера ----------
def collect_roles(guild) -> list:
    roles = []
    for role in guild.roles:
        # пропускаем @everyone и роли ботов/интеграций (managed)
        if role.is_default() or role.managed:
            continue
        roles.append({
            "name": role.name,
            "color": role.color.value,
            "hoist": role.hoist,
            "mentionable": role.mentionable,
            "permissions": role.permissions.value,
            "position": role.position,
        })
    return roles


def collect_channels(guild):
    categories = []
    for cat in guild.categories:
        categories.append({
            "name": cat.name,
            "position": cat.position,
            "overwrites": serialize_overwrites(cat),
        })

    channels = []
    for ch in guild.channels:
        if isinstance(ch, discord.CategoryChannel):
            continue
        item = {
            "name": ch.name,
            "type": ch.type.name,  # text, voice, news, stage_voice, forum
            "category": ch.category.name if ch.category else None,
            "position": ch.position,
            "overwrites": serialize_overwrites(ch),
        }
        if isinstance(ch, (discord.TextChannel, discord.ForumChannel)):
            item["topic"] = ch.topic
            item["nsfw"] = ch.nsfw
            item["slowmode"] = ch.slowmode_delay
        if isinstance(ch, (discord.VoiceChannel, discord.StageChannel)):
            item["bitrate"] = ch.bitrate
            item["user_limit"] = ch.user_limit
        channels.append(item)
    return categories, channels


# ---------- применение шаблона ----------
async def apply_roles(guild, saved_roles: list, role_map: dict, template_name: str):
    created, skipped, failed = 0, 0, []
    # создаём снизу вверх, чтобы порядок ролей сохранился
    for r in sorted(saved_roles, key=lambda x: x["position"]):
        if r["name"] in role_map:
            skipped += 1
            continue
        try:
            role_map[r["name"]] = await guild.create_role(
                name=r["name"],
                colour=discord.Colour(r["color"]),
                hoist=r["hoist"],
                mentionable=r["mentionable"],
                permissions=discord.Permissions(r["permissions"]),
                reason=f"Шаблон {template_name}",
            )
            created += 1
        except discord.HTTPException as e:
            failed.append(f"роль {r['name']}: {e}")
    return created, skipped, failed


async def apply_channels(guild, categories: list, channels: list, role_map: dict, template_name: str):
    stats = {"cat": 0, "ch": 0, "skipped": 0}
    failed = []
    reason = f"Шаблон {template_name}"
    cat_map = {c.name: c for c in guild.categories}

    # 1) категории
    for c in sorted(categories, key=lambda x: x["position"]):
        if c["name"] in cat_map:
            stats["skipped"] += 1
            continue
        try:
            cat_map[c["name"]] = await guild.create_category(
                c["name"],
                overwrites=build_overwrites(guild, role_map, c["overwrites"]),
                reason=reason,
            )
            stats["cat"] += 1
        except discord.HTTPException as e:
            failed.append(f"категория {c['name']}: {e}")

    # 2) каналы
    for ch in sorted(channels, key=lambda x: x["position"]):
        parent = cat_map.get(ch["category"]) if ch["category"] else None
        siblings = parent.channels if parent else [x for x in guild.channels if x.category is None]
        if any(x.name == ch["name"] and x.type.name == ch["type"] for x in siblings):
            stats["skipped"] += 1
            continue

        kwargs = {
            "overwrites": build_overwrites(guild, role_map, ch["overwrites"]),
            "reason": reason,
        }
        if parent:
            kwargs["category"] = parent

        t = ch["type"]
        try:
            if t in ("text", "news"):
                try:
                    await guild.create_text_channel(
                        ch["name"],
                        topic=ch.get("topic") or None,
                        nsfw=ch.get("nsfw", False),
                        slowmode_delay=ch.get("slowmode", 0) or 0,
                        news=(t == "news"),
                        **kwargs,
                    )
                except discord.HTTPException:
                    if t != "news":
                        raise
                    # на сервере нет режима «Сообщество» — делаем обычный текстовый канал
                    await guild.create_text_channel(
                        ch["name"],
                        topic=ch.get("topic") or None,
                        nsfw=ch.get("nsfw", False),
                        **kwargs,
                    )
            elif t == "voice":
                await guild.create_voice_channel(
                    ch["name"],
                    bitrate=min(int(ch.get("bitrate", 64000)), int(guild.bitrate_limit)),
                    user_limit=ch.get("user_limit", 0) or 0,
                    **kwargs,
                )
            elif t == "stage_voice":
                await guild.create_stage_channel(ch["name"], topic=ch["name"], **kwargs)
            elif t == "forum":
                await guild.create_forum(
                    ch["name"],
                    topic=ch.get("topic") or None,
                    nsfw=ch.get("nsfw", False),
                    slowmode_delay=ch.get("slowmode", 0) or 0,
                    **kwargs,
                )
            else:
                failed.append(f"канал {ch['name']}: тип {t} не поддерживается")
                continue
            stats["ch"] += 1
        except discord.HTTPException as e:
            failed.append(f"канал {ch['name']}: {e}")

    return stats, failed


# ---------- бот ----------
intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


@client.event
async def on_ready():
    await tree.sync()
    print(f"Бот v{VERSION} запущен как {client.user}")


@tree.command(name="save_template", description="Сохранить роли, категории и каналы сервера как шаблон")
@app_commands.describe(name="Название шаблона")
@app_commands.checks.has_permissions(administrator=True)
async def save_template(interaction: discord.Interaction, name: str):
    guild = interaction.guild
    categories, channels = collect_channels(guild)
    roles = collect_roles(guild)

    data = load_templates()
    data[name] = {
        "source_guild": guild.name,
        "roles": roles,
        "categories": categories,
        "channels": channels,
    }
    save_templates(data)
    await interaction.response.send_message(
        f"Шаблон **{name}** сохранён: ролей {len(roles)}, "
        f"категорий {len(categories)}, каналов {len(channels)}.",
        ephemeral=True,
    )


@tree.command(name="apply_template", description="Создать роли, категории и каналы из шаблона")
@app_commands.describe(
    name="Название шаблона",
    roles="Создавать роли (по умолчанию да)",
    channels="Создавать категории и каналы (по умолчанию да)",
)
@app_commands.checks.has_permissions(administrator=True)
async def apply_template(
    interaction: discord.Interaction,
    name: str,
    roles: bool = True,
    channels: bool = True,
):
    data = load_templates()
    if name not in data:
        await interaction.response.send_message("Такого шаблона нет.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    guild = interaction.guild
    tpl = data[name]
    role_map = {r.name: r for r in guild.roles}
    lines, failed = [], []

    if roles:
        c, s, f = await apply_roles(guild, tpl.get("roles", []), role_map, name)
        failed += f
        lines.append(f"Роли: создано {c}, пропущено (уже есть) {s}.")

    if channels:
        if not tpl.get("channels") and not tpl.get("categories"):
            lines.append("В этом шаблоне нет каналов (он сохранён старой версией бота). Сохрани его заново.")
        else:
            st, f = await apply_channels(
                guild, tpl.get("categories", []), tpl.get("channels", []), role_map, name
            )
            failed += f
            lines.append(
                f"Категории: создано {st['cat']}. Каналы: создано {st['ch']}. "
                f"Пропущено (уже есть): {st['skipped']}."
            )

    if failed:
        lines.append(f"Ошибок: {len(failed)}. Первые:\n" + "\n".join(failed[:5]))

    text = "\n".join(lines)[:1900]
    try:
        await interaction.followup.send(text)
    except discord.HTTPException:
        await interaction.channel.send(text)


@tree.command(name="list_templates", description="Показать сохранённые шаблоны")
async def list_templates(interaction: discord.Interaction):
    data = load_templates()
    if not data:
        await interaction.response.send_message("Шаблонов пока нет.", ephemeral=True)
        return
    lines = [
        f"• **{n}**: ролей {len(t.get('roles', []))}, категорий {len(t.get('categories', []))}, "
        f"каналов {len(t.get('channels', []))} (с сервера {t['source_guild']})"
        for n, t in data.items()
    ]
    await interaction.response.send_message("\n".join(lines), ephemeral=True)


@tree.command(name="delete_template", description="Удалить шаблон")
@app_commands.describe(name="Название шаблона")
@app_commands.checks.has_permissions(administrator=True)
async def delete_template(interaction: discord.Interaction, name: str):
    data = load_templates()
    if name not in data:
        await interaction.response.send_message("Такого шаблона нет.", ephemeral=True)
        return
    del data[name]
    save_templates(data)
    await interaction.response.send_message(f"Шаблон **{name}** удалён.", ephemeral=True)


@tree.error
async def on_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        await interaction.response.send_message("Нужны права администратора.", ephemeral=True)
    else:
        raise error


client.run(load_token())
